<?php

namespace App\Filament\Resources\Tables\Columns;

use Filament\Tables\Columns\Column;

class Attribute extends Column
{
    protected string $name = 'attribute';
}
