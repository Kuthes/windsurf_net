<?php

namespace App\Filament\Resources\Tables\Filters;

use Filament\Tables\Filters\TextFilter;

class Shortname extends TextFilter
{
    protected string $name = 'shortname';
}
