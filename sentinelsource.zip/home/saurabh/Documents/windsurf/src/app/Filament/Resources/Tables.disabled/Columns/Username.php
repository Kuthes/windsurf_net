<?php

namespace App\Filament\Resources\Tables\Columns;

use Filament\Tables\Columns\Column;

class Username extends Column
{
    protected string $name = 'username';
}
