<?php

namespace App\Filament\Resources\Tables\Columns;

use Filament\Tables\Columns\Column;

class Ports extends Column
{
    protected string $name = 'ports';
}
