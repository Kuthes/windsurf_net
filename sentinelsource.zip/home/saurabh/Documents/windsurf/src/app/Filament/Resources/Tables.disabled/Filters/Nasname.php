<?php

namespace App\Filament\Resources\Tables\Filters;

use Filament\Tables\Filters\TextFilter;

class Nasname extends TextFilter
{
    protected string $name = 'nasname';
}
