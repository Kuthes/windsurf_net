<?php

namespace App\Filament\Resources\DataPackResource\Pages;

use App\Filament\Resources\DataPackResource;
use Filament\Resources\Pages\CreateRecord;

class CreateDataPack extends CreateRecord
{
    protected static string $resource = DataPackResource::class;
}
