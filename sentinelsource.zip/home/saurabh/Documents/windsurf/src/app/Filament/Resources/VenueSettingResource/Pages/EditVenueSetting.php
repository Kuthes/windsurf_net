<?php

namespace App\Filament\Resources\VenueSettingResource\Pages;

use App\Filament\Resources\VenueSettingResource;
use Filament\Resources\Pages\EditRecord;

class EditVenueSetting extends EditRecord
{
    protected static string $resource = VenueSettingResource::class;
}
