<?php

namespace App\Filament\Resources\Tables\Filters;

use Filament\Tables\Filters\TextFilter;

class Username extends TextFilter
{
    protected string $name = 'username';
}
