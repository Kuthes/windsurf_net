<?php

namespace App\Filament\Resources\Tables\Columns;

use Filament\Tables\Columns\Column;

class CreatedAt extends Column
{
    protected string $name = 'created_at';
}
