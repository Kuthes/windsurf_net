<?php

namespace App\Filament\Resources\Tables\Columns;

use Filament\Tables\Columns\Column;

class UpdatedAt extends Column
{
    protected string $name = 'updated_at';
}
