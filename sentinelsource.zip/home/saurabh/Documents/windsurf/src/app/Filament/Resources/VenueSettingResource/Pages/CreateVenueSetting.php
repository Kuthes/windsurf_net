<?php

namespace App\Filament\Resources\VenueSettingResource\Pages;

use App\Filament\Resources\VenueSettingResource;
use Filament\Resources\Pages\CreateRecord;

class CreateVenueSetting extends CreateRecord
{
    protected static string $resource = VenueSettingResource::class;
}
