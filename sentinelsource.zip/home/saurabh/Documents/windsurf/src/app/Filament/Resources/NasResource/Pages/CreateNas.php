<?php

namespace App\Filament\Resources\NasResource\Pages;

use App\Filament\Resources\NasResource;
use Filament\Resources\Pages\CreateRecord;

class CreateNas extends CreateRecord
{
    protected static string $resource = NasResource::class;
}
