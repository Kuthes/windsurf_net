<?php

namespace App\Filament\Resources\RadCheckResource\Pages;

use App\Filament\Resources\RadCheckResource;
use Filament\Resources\Pages\CreateRecord;

class CreateRadCheck extends CreateRecord
{
    protected static string $resource = RadCheckResource::class;
}
