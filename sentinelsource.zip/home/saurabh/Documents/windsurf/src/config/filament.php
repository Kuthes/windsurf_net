<?php

return [
    'default' => [
        'path' => 'admin',
        'auth' => [
            'guard' => 'web',
        ],
        'pages' => [
            //
        ],
    ],
];
